import{c as e,d as n,o as s}from"./style.157004c7.js";const c=async()=>{await s()},i=()=>{e(c),n("check-selected",c)};i();
